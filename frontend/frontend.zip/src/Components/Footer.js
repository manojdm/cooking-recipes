import React from 'react'
import  '../css/footer.css'

const Footer = () => {
    return (
        <footer id="footer">
            <p className="footer-p">
                CopyRight &copy; DM
            </p>
        </footer>
    )
}

export default Footer
